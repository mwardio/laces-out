// src/protocol.ts
var maximumLeagueCount = 32;
var configurationStorageKey = "lacesOutEspnConfiguration";
var statusStorageKey = "lacesOutEspnStatus";
var syncAlarmName = "laces-out-espn-sync";
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function parseLeagueIds(value) {
  const leagueIds = value.split(/[\s,]+/u).map((leagueId) => leagueId.trim()).filter(Boolean);
  return validateLeagueIds(leagueIds);
}
function validateLeagueIds(value) {
  if (!Array.isArray(value) || value.length === 0) {
    throw new TypeError("Enter at least one ESPN league ID");
  }
  if (value.length > maximumLeagueCount) {
    throw new TypeError(`A bridge can sync at most ${maximumLeagueCount} ESPN leagues`);
  }
  const leagueIds = value.map((candidate) => {
    if (typeof candidate !== "string") throw new TypeError("ESPN league IDs must be text");
    const leagueId = candidate.trim();
    if (!/^\d{1,20}$/u.test(leagueId)) {
      throw new TypeError("Each ESPN league ID must contain 1 to 20 digits");
    }
    return leagueId;
  });
  if (new Set(leagueIds).size !== leagueIds.length) {
    throw new TypeError("ESPN league IDs must be unique");
  }
  return leagueIds;
}
function validateBridgeConfiguration(value) {
  if (!isRecord(value)) throw new TypeError("Bridge configuration is missing");
  const apiBaseUrl = typeof value.apiBaseUrl === "string" ? value.apiBaseUrl.trim() : "";
  const deviceToken = typeof value.deviceToken === "string" ? value.deviceToken.trim() : "";
  const leagueIds = validateLeagueIds(value.leagueIds);
  const season = value.season;
  const automaticSync = value.automaticSync;
  const apiUrl = new URL(apiBaseUrl);
  const localDevelopment = apiUrl.protocol === "http:" && ["localhost", "127.0.0.1"].includes(apiUrl.hostname);
  if (apiUrl.protocol !== "https:" && !localDevelopment || apiUrl.username !== "" || apiUrl.password !== "" || apiUrl.search !== "" || apiUrl.hash !== "") {
    throw new TypeError("Laces Out URL must be HTTPS or a loopback development URL");
  }
  if (deviceToken.length < 32 || deviceToken.length > 512) {
    throw new TypeError("Laces Out device token is invalid");
  }
  if (typeof season !== "number" || !Number.isSafeInteger(season) || season < 2e3 || season > 2100) {
    throw new TypeError("ESPN season is invalid");
  }
  if (typeof automaticSync !== "boolean") throw new TypeError("Automatic sync setting is invalid");
  return {
    apiBaseUrl: apiUrl.origin,
    deviceToken,
    leagueIds,
    season,
    automaticSync
  };
}
function summarizeBridgeResults(results) {
  if (results.length === 0) throw new TypeError("Bridge sync results cannot be empty");
  const synced = results.filter((result) => result.state === "synced").length;
  const loginRequired = results.filter((result) => result.state === "espn-login-required").length;
  const pairingFailed = results.filter((result) => result.state === "laces-out-auth-failed").length;
  if (synced === results.length) {
    return {
      state: "healthy",
      message: `Synced ${synced} ESPN ${synced === 1 ? "league" : "leagues"}.`
    };
  }
  if (synced > 0) {
    return {
      state: "partial-failure",
      message: `Synced ${synced} of ${results.length} ESPN leagues; ${results.length - synced} ${results.length - synced === 1 ? "needs" : "need"} attention.`
    };
  }
  if (loginRequired > 0) {
    return {
      state: "espn-login-required",
      message: loginRequired === results.length ? "Sign in to ESPN in this browser, then sync again." : `${loginRequired} of ${results.length} leagues require ESPN sign-in; review the league results.`
    };
  }
  if (pairingFailed > 0) {
    return {
      state: "laces-out-auth-failed",
      message: "Laces Out pairing was rejected. Create and configure a new bridge device token."
    };
  }
  return {
    state: "error",
    message: `None of the ${results.length} ESPN leagues synced; review the league results.`
  };
}

export {
  configurationStorageKey,
  statusStorageKey,
  syncAlarmName,
  parseLeagueIds,
  validateBridgeConfiguration,
  summarizeBridgeResults
};
//# sourceMappingURL=chunk-QT5NDZYM.js.map