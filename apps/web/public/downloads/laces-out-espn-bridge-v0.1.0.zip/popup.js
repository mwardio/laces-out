import {
  parseLeagueIds,
  validateBridgeConfiguration
} from "./chunk-QT5NDZYM.js";

// src/popup.ts
function element(id) {
  const value = document.getElementById(id);
  if (!value) throw new Error(`Missing popup element: ${id}`);
  return value;
}
var form = element("configuration-form");
var statusPanel = element("status");
var statusMessage = element("status-message");
var lastSync = element("last-sync");
var leagueResults = element("league-results");
var syncButton = element("sync-now");
var forgetBrowserButton = element("forget-browser");
var loginButton = element("open-espn");
function send(request) {
  return chrome.runtime.sendMessage(request);
}
function formString(data, name) {
  const value = data.get(name);
  return typeof value === "string" ? value : "";
}
function render(status) {
  statusPanel.dataset.state = status.state;
  statusMessage.textContent = status.message;
  lastSync.textContent = status.lastSuccessfulAt ? new Date(status.lastSuccessfulAt).toLocaleString() : "Never";
  syncButton.disabled = !status.configured || status.state === "syncing";
  forgetBrowserButton.hidden = !status.configured;
  loginButton.hidden = !(status.state === "espn-login-required" || status.results.some((result) => result.state === "espn-login-required"));
  form.hidden = status.configured;
  leagueResults.replaceChildren(
    ...status.results.map((result) => {
      const item = document.createElement("li");
      item.dataset.state = result.state;
      const league = document.createElement("strong");
      league.textContent = result.leagueId;
      const outcome = document.createElement("span");
      outcome.textContent = resultLabel(result.state);
      const message = document.createElement("small");
      message.textContent = result.message;
      item.append(league, outcome, message);
      return item;
    })
  );
  leagueResults.hidden = status.results.length === 0;
}
function resultLabel(state) {
  if (state === "synced") return "Synced";
  if (state === "espn-login-required") return "ESPN sign-in required";
  if (state === "laces-out-auth-failed") return "Pairing rejected";
  return "Failed";
}
async function requireApiPermission(apiBaseUrl) {
  const url = new URL(apiBaseUrl);
  const originPattern = `${url.protocol}//${url.hostname}/*`;
  const allowed = await chrome.permissions.request({ origins: [originPattern] });
  if (!allowed) throw new Error("Laces Out host permission was not granted");
}
form.addEventListener("submit", (event) => {
  event.preventDefault();
  void (async () => {
    const data = new FormData(form);
    const configuration = validateBridgeConfiguration({
      apiBaseUrl: formString(data, "apiBaseUrl"),
      deviceToken: formString(data, "deviceToken"),
      leagueIds: parseLeagueIds(formString(data, "leagueIds")),
      season: Number(data.get("season")),
      automaticSync: data.get("automaticSync") === "on"
    });
    await requireApiPermission(configuration.apiBaseUrl);
    render((await send({ type: "CONFIGURE", configuration })).status);
  })().catch((error) => {
    statusMessage.textContent = error instanceof Error ? error.message : "Pairing failed";
    statusPanel.dataset.state = "error";
  });
});
syncButton.addEventListener("click", () => {
  syncButton.disabled = true;
  statusMessage.textContent = "Starting ESPN sync\u2026";
  void send({ type: "SYNC_NOW" }).then((response) => render(response.status)).catch((error) => {
    syncButton.disabled = false;
    statusMessage.textContent = error instanceof Error ? error.message : "ESPN sync failed";
    statusPanel.dataset.state = "error";
  });
});
forgetBrowserButton.addEventListener("click", () => {
  void send({ type: "DISCONNECT" }).then((response) => render(response.status)).catch((error) => {
    statusMessage.textContent = error instanceof Error ? error.message : "Local forget failed";
    statusPanel.dataset.state = "error";
  });
});
loginButton.addEventListener("click", () => {
  void chrome.tabs.create({ url: "https://fantasy.espn.com/football/" });
});
void send({ type: "GET_STATUS" }).then((response) => render(response.status)).catch((error) => {
  statusMessage.textContent = error instanceof Error ? error.message : "Bridge status failed";
  statusPanel.dataset.state = "error";
});
//# sourceMappingURL=popup.js.map